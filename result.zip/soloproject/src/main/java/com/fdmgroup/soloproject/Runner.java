package com.fdmgroup.soloproject;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import daoClasses.CardDAO;
import daoClasses.CustomerDAO;
import daoClasses.ItemDAO;
import daoClasses.OrderDAO;
import entity.Card;
import entity.Customer;
import entity.Item;
import entity.Order;

public class Runner {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa_demo");

		CustomerDAO customerDAO = new CustomerDAO(emf);

		Item item1 = new Item("item1", "description", 1.1, 1);
		Item item2 = new Item("item2", "description", 2.2, 2);
		Item item3 = new Item("item3", "description", 3.3, 3);
		Item item4 = new Item("item4", "description", 4.4, 4);
		Item item5 = new Item("item5", "description", 5.5, 5);
		List<Item> listofItem = new ArrayList<Item>();
		ItemDAO itemDAO = new ItemDAO(emf);

		listofItem.add(item1);
		listofItem.add(item2);
		listofItem.add(item4);
		listofItem.add(item5);

		OrderDAO orderDAO = new OrderDAO(emf);
		Order order = new Order("1", 1.1, "11", true, listofItem);
		ArrayList<Order> listorder = new ArrayList<Order>();
		listorder.add(order);

		Card card1 = new Card("1", 1.1, 1.1, 1.1, 1.1, "1");
		Card card2 = new Card("2", 2, 2, 2, 2, "2");
		Card card3 = new Card("3", 3.3, 3, 3, 3, "3");
		Card card4 = new Card("4", 4, 4, 4, 4, "4");

		CardDAO cardDAO = new CardDAO(emf);
		ArrayList<Card> listcard = new ArrayList<Card>();
		listcard.add(card1);
		listcard.add(card2);
		listcard.add(card3);
		listcard.add(card4);

		Customer customer = new Customer("1", "1", "1", "1", "1", "1", 1.1, listorder, listcard);

		cardDAO.addCard(card1);
		cardDAO.addCard(card2);
		cardDAO.addCard(card3);
		cardDAO.addCard(card4);
		itemDAO.addItem(item1);
		itemDAO.addItem(item2);
		itemDAO.addItem(item3);
		itemDAO.addItem(item4);

		itemDAO.addItem(item5);
		orderDAO.addOrder(order);
		customerDAO.addCustomer(customer);
		System.out.println(customerDAO.getallCustomer().get(0).toString());
	}

}
