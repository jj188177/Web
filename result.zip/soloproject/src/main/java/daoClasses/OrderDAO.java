package daoClasses;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import entity.Order;

public class OrderDAO {

	private EntityManagerFactory emf;

	public OrderDAO(EntityManagerFactory emf) {
		this.emf = emf;
	}

	public void addOrder(Order order) {
		EntityManager entityManager = emf.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		entityManager.persist(order);
		transaction.commit();
		entityManager.close();
	}

	public List<Order> getallOrders() {
		EntityManager entityManager = emf.createEntityManager();
		TypedQuery<Order> query = entityManager.createQuery("SELECT d FROM Order d", Order.class);
		List<Order> orderList = query.getResultList();
		entityManager.close();
		return orderList;

	}

}
