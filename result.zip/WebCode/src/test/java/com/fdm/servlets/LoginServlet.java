package com.fdm.servlets;

import java.io.IOException;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		RequestDispatcher rd = req.getRequestDispatcher("login.jsp");
		rd.forward(req, resp);

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		HttpSession session = req.getSession();
		// req.setAttribute("Luck", new int[] {1,2,3,4,5,6});
		//
		// System.out.println(username + " " + password);

		// better to call a login servlet class here

		RequestDispatcher rd = null;

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa_demo");
		CustomerDAO customerDAO = new CustomerDAO(emf);
		Customer customer = customerDAO.getCustomer(email);

		if (customer == null) {
			req.setAttribute("emailERROR", "invalid email!");
			rd = req.getRequestDispatcher("login.jsp");
		} else if (!(customer.getPassword().equals(password))) {
			req.setAttribute("passERROR", "wrong password!");
			rd = req.getRequestDispatcher("login.jsp");
		} else {
			rd = req.getRequestDispatcher("home.jsp");
		}
		
		rd.forward(req, resp);

	}

}
