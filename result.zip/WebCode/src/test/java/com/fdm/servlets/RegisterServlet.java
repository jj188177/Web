package com.fdm.servlets;

import java.io.IOException;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class RegisterServlet extends HttpServlet {

	// ${pageContext.request.contextPath}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		RequestDispatcher rd = req.getRequestDispatcher("register.jsp");
		System.out.println("register");
		rd.forward(req, resp);

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String email = req.getParameter("email");
		String password = req.getParameter("password");
		String firstName = req.getParameter("firstName");
		String lastName = req.getParameter("lastName");
		String address = req.getParameter("address");
		System.out.println("parameter getted");
		RequestDispatcher rd = null;
		HttpSession session = req.getSession();
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa_demo");
		CustomerDAO customerDAO = new CustomerDAO(emf);
		Customer customer = customerDAO.getCustomer(email);
				

		if (!(customer == null)) {
			req.setAttribute("exist", "Oops email already exist!");
			rd = req.getRequestDispatcher("register.jsp");
		} else if (email.length() < 3 || !(email.contains("@"))) {
			req.setAttribute("emailERROR", "length of email should be greater than 3 character and contain @");
			rd = req.getRequestDispatcher("register.jsp");
		} else if (password.length() < 3) {
			req.setAttribute("passwordERROR",
					"length of password should be greater than 3 characters and less than 9 characters");
			rd = req.getRequestDispatcher("register.jsp");
		} else if (firstName.length() < 3) {
			req.setAttribute("firstNameERROR", "First name too short");
			rd = req.getRequestDispatcher("register.jsp");
		} else if (lastName.length() < 3) {
			req.setAttribute("lastNameERROR", "last name too short");
			rd = req.getRequestDispatcher("register.jsp");
		} else if (address.length() < 3) {
			req.setAttribute("addressERROR", "address too short");
			rd = req.getRequestDispatcher("register.jsp");
		} else {
			Customer customerToAdd = new Customer();
			customerToAdd.setAddress(address);
			customerToAdd.setEmail(email);
			customerToAdd.setPassword(password);
			customerToAdd.setFirstName(firstName);
			customerToAdd.setLastName(lastName);
			customerDAO.addCustomer(customerToAdd);
			session.setAttribute("email", email);
			session.setAttribute("password", password);
			session.setAttribute("firstName", firstName);
			session.setAttribute("lastName", lastName);
			
			rd = req.getRequestDispatcher("welcome.jsp");
		}

		rd.forward(req, resp);

	}

}
